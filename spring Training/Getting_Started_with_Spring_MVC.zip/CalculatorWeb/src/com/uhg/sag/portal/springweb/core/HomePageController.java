package com.uhg.sag.portal.springweb.core;

import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.AbstractController;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.*;

/**
 * Controller to generate the Home Page basics to be rendered by a view. It extends the convenience class
 * AbstractController that encapsulates most of the drudgery involved in handling HTTP requests.
 */
public class HomePageController extends AbstractController
{
    protected ModelAndView handleRequestInternal(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse) throws Exception
    {
        // the time at the server
        Calendar cal = Calendar.getInstance(Locale.UK);
        Date now = cal.getTime();

        // time-of-day dependent greeting
        String greeting = "Morning";
        int hour = cal.get(Calendar.HOUR_OF_DAY);
        if (hour == 12)
        {
            greeting = "Day";
        }
        else if (hour > 18)
        {
            greeting = "Evening";
        }
        else if (hour > 12)
        {
            greeting = "Afternoon";
        }

        // Set the objects in the modelAndView. These will be used by the view (JSP) to render results
        ModelAndView modelAndView = new ModelAndView();
        modelAndView.addObject("time", now);
        modelAndView.addObject("greeting", greeting);
        modelAndView.setViewName("home");

        return modelAndView;
    }
}
