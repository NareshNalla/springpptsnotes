package com.uhg.sag.portal.springweb.core;

import org.springframework.web.servlet.mvc.SimpleFormController;

public class CalculatorController extends SimpleFormController
{
    protected void doSubmitAction(Object o) throws Exception
    {
        CalculatorDTO calc = (CalculatorDTO)o;
        
        calc.setResult(calc.getFirstNumber() + calc.getSecondNumber());
    }
}
