package com.uhg.sag.portal.springweb.core;

public class CalculatorDTO
{
    private Integer firstNumber;
    private Integer secondNumber;
    private Integer result;


    public Integer getFirstNumber()
    {
        return firstNumber;
    }


    public void setFirstNumber(Integer firstNumber)
    {
        this.firstNumber = firstNumber;
    }


    public Integer getSecondNumber()
    {
        return secondNumber;
    }


    public void setSecondNumber(Integer secondNumber)
    {
        this.secondNumber = secondNumber;
    }


    public Integer getResult()
    {
        return result;
    }


    public void setResult(Integer result)
    {
        this.result = result;
    }


    public Boolean getShowResult()
    {
        if (this.result != null)
        {
            return true;
        }
        else
        {
            return false;
        }
    }
}
